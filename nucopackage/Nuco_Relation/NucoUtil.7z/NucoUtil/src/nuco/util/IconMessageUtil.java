package nuco.util;

import java.awt.TrayIcon;
import java.awt.TrayIcon.MessageType;

public class IconMessageUtil {

	public String caption;		// キャプション
	public String message;		// メッセージ
	public MessageType type;	// タイプ

	/**
	 * コンストラクタ
	 * @param icon
	 */
	public IconMessageUtil() {}

	/**
	 * メッセージを表示
	 * @throws Exception
	 */
	public void displayMessage(TrayIcon icon, String caption, String message, MessageType type) throws Exception {
		this.caption = caption;
		this.message = message;
		this.type = type;
		icon.displayMessage(caption, message, type);
	}

	/**
	 * 直前のメッセージを表示
	 * @throws Exception
	 */
	public void displayMessage(TrayIcon icon) throws Exception {
		icon.displayMessage(caption, message, type);
	}

}
