package nuco.util;

import java.awt.TrayIcon;
import java.awt.TrayIcon.MessageType;

public class NucoUtil {

	private int errorCount;			// Error Count.
	public IconMessageUtil icon;	// システムトレイアイコンユーティリティ

	/**
	 * Constructor.
	 */
	public NucoUtil()  {}
	
	/**
	 * Constructor.
	 */
	public NucoUtil(TrayIcon icon)  {
		errorCount = 0;
		this.icon = new IconMessageUtil();
	}

	/**
	 * メッセージを表示
	 * @throws Exception
	 */
	public void displayMessage(TrayIcon icon, String caption, String message, MessageType type) throws Exception {
		this.icon.displayMessage(icon, caption, message, type);
	}

	/**
	 * 直前のメッセージを表示
	 * @throws Exception
	 */
	public void displayMessage(TrayIcon icon) throws Exception {
		this.icon.displayMessage(icon);
	}

	/**
	 * 何度もエラーを出すと、怒られるメッセージを表示
	 * @param title
	 * @param message
	 * @param count
	 * @param sleepMills
	 * @throws Exception
	 */
	public void displayMostErrorMessage(TrayIcon icon, String title, String message, int count, long sleepMills) throws Exception {
		errorCount++;
		if (errorCount > count) {
			try { Thread.sleep(sleepMills); } catch (Exception e) {}
			icon.displayMessage(title, message, MessageType.ERROR);
			errorCount = 0;
		}
	}
	
	/**
	 * Get Version Method.
	 * @return String
	 */
	public String getVersion() {
		return "Nuco Utility ver.0.0.1";
	}

}
