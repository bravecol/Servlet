package nuco.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class StringUtil {

	public static final String RN	= "\r\n";
	public static final String TAB	= "\t";

	public static final String N_STRING	= "\\n";

	/**
	 * データを文字列に変換する処理
	 * @param buff
	 * @param data
	 * @param tabCount
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public String convertDataString(Object data, int tabCount) throws Exception {
		StringBuffer buff = new StringBuffer();
		if (data == null) {
			buff.append("null");
		} else if (data instanceof Map) {
			buff.append("{");
			buff.append(RN);
			int index = 0;
			Map<String, ?> map = (Map<String, ?>)data;
			for (String key : map.keySet()) {
				Object data2 = map.get(key);
				if (index != 0) buff.append(",");
				for (int i = 0; i < tabCount; i++) {
					buff.append(TAB);
				}
				buff.append(TAB);
				buff.append(key);
				buff.append(" : ");
				buff.append(convertDataString(data2, tabCount + 1));
				index++;
			}
			for (int i = 0; i < tabCount; i++) {
				buff.append(TAB);
			}
			buff.append("}");
		} else if (data instanceof List) {
			List<?> list = (ArrayList<?>)data;
			buff.append("[");
			if (!list.isEmpty()) {
				for (Object data2 : list) {
					if (list.indexOf(data2) != 0) buff.append(",");
					buff.append(convertDataString(data2, tabCount + 1));
				}
				for (int i = 0; i < tabCount; i++) {
					buff.append(TAB);
				}
			}
			buff.append("]");
		} else if (data instanceof Date) {
			buff.append(new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS").format(data));
		} else {
			buff.append(data.toString());
		}
		buff.append(RN);
		return buff.toString();
	}
	
	/**
	 * Plus Values Method.
	 * @param value1
	 * @param value2
	 * @return String
	 */
	public String plus(String value1, String value2) {
		return String.valueOf(Integer.parseInt(value1) + Integer.parseInt(value2));
	}

}
